/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js!./source/animation.css":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js!./source/animation.css ***!
  \**************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ \"./node_modules/css-loader/dist/runtime/api.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);\n// Imports\n\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \".app-header {\\n\\t/* 0% */\\n\\topacity: 0;\\n\\ttransform: translateY(-4rem);\\n\\t/* 100% */\\n\\tanimation: transform-none 0.35s 0.4s ease-out forwards;\\n}\\n\\n.brand {\\n\\topacity: 0;\\n\\ttransform: translateX(-4rem);\\n\\tanimation: transform-none 0.3s 0.7s cubic-bezier(0, 0, 0.23, 1.43) forwards;\\n}\\n\\nbutton[title=\\\"메뉴 열기\\\"] {\\n\\topacity: 0;\\n\\ttransform: translateX(4rem);\\n\\tanimation: transform-none 0.45s 0.65s cubic-bezier(0, 0, 0, 1) forwards;\\n}\\n\\n.ediya-menu__item {\\n\\topacity: 0;\\n\\ttransform: translateY(4rem);\\n\\tanimation: transform-none 0.3s 0.85s cubic-bezier(0.6, 0.01, 0.16, 1) forwards;\\n}\\n\\n.ediya-menu__item:nth-child(1) {\\n\\tanimation-duration: 0.8s;\\n}\\n.ediya-menu__item:nth-child(2) {\\n\\tanimation-duration: 1.2s;\\n}\\n.ediya-menu__item:nth-child(3) {\\n\\tanimation-duration: 1.6s;\\n}\\n.ediya-menu__item:nth-child(4) {\\n\\tanimation-duration: 2.0s;\\n}\\n\\n@keyframes transform-none {\\n\\tto {\\n\\t\\ttransform: none;\\n\\t\\topacity: 1;\\n\\t}\\n}\\n\", \"\"]);\n// Exports\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);\n\n\n//# sourceURL=webpack://RWD/./source/animation.css?./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js");

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js!./source/style.css":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js!./source/style.css ***!
  \**********************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ \"./node_modules/css-loader/dist/runtime/api.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _node_modules_css_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./animation.css */ \"./node_modules/css-loader/dist/cjs.js!./source/animation.css\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/getUrl.js */ \"./node_modules/css-loader/dist/runtime/getUrl.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);\n// Imports\n\n\n\nvar ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(/*! ../images/button-navigation.png */ \"./images/button-navigation.png\"), __webpack_require__.b);\nvar ___CSS_LOADER_URL_IMPORT_1___ = new URL(/* asset import */ __webpack_require__(/*! ../images/button-navigation@2x.png */ \"./images/button-navigation@2x.png\"), __webpack_require__.b);\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});\n___CSS_LOADER_EXPORT___.push([module.id, \"@import url(//spoqa.github.io/spoqa-han-sans/css/SpoqaHanSansNeo.css);\"]);\n___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_1__.default);\nvar ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);\nvar ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_1___);\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \"::-moz-selection {\\n  background: #233d84;\\n  color: #ffffff;\\n}\\n\\n::selection {\\n  background: #233d84;\\n  color: #ffffff;\\n}\\n\\n/* 숨김 콘텐츠 */\\n.a11y-hidden {\\n  overflow: hidden;\\n  position: absolute !important;\\n  top: -9999em;\\n  clip: rect(0, 0, 0, 0);\\n  width: 1px;\\n  height: 1px;\\n  margin: -1px;\\n}\\n\\nbody * {\\n  -webkit-tap-highlight-color: rgba(255, 255, 200, 0.3);\\n  tap-highlight-color: rgba(255, 255, 200, 0.3);\\n}\\n\\na img {\\n  vertical-align: middle;\\n}\\na{\\n  color: inherit;\\n  text-decoration: none;\\n}\\na:focus{\\n  outline-offset: -2px;\\n}\\n/* 반응형 이미지 및 미디어 */\\n.fullsize-max{\\n  max-width: 100%;\\n  height: auto;\\n}\\n.fullsize{\\n  width: 100%;\\n  height: auto;\\n}\\n/* ul, li 여백 및 블릿 제거 */\\n.reset-list {\\n  margin-top: 0;\\n  margin-bottom: 0;\\n  padding-left: 0;\\n  list-style: none;\\n}\\n/* button */\\n.button{\\n  cursor: pointer;\\n  border: 0;\\n}\\n\\n/* 컨테이너 */\\n.container {\\n  margin: 0 auto;\\n}\\n/* --------------------------------------------\\n  * 헤더 디자인 */\\n\\n.header {\\n  position: fixed;\\n  z-index: 600;\\n  top: 0;\\n  left: 0;\\n  right: 0;\\n  display: flex;\\n  justify-content: space-between;\\n  background: rgba(255, 255, 255, 0.4);\\n  margin-bottom: 1.875em; /* 30px */\\n  border-bottom: 1px solid #e0e0e0;\\n}\\n\\n/* 브랜드 로고 디자인 */\\n.brand {\\n  font-size: 1em;\\n  margin-top: 0;\\n  margin-bottom: 0;\\n  width: 46.93333333333333%; /* 176px/375px */\\n  min-width: 158px;\\n}\\n.brand a {\\n  display: inline-block;\\n  padding: 1.125rem; /* 18px/16px */\\n}\\n\\n/* 내비게이션 열기 버튼 */\\n.header .button-open-menu{\\n  -webkit-user-select: none;\\n  -moz-user-select: none;\\n  -ms-user-select: none;\\n  user-select: none;\\n  padding: 0;\\n  background: #ffffff;\\n  transition: all 0.3s ease;\\n}\\n\\n.header .button-open-menu .ir {\\n  display: block;\\n  cursor: pointer;\\n  width: 50px;\\n  height: 50px;\\n  background: url(\" + ___CSS_LOADER_URL_REPLACEMENT_0___ + \") no-repeat 50% / cover;\\n}\\n\\n.header .button-open-menu:hover .ir,\\n.header .button-open-menu:focus .ir{\\n  background-color: #f5f5f5;\\n  box-shadow: 0 0 1px 1px #eee;\\n}\\n\\n/* 내비게이션 디자인 */\\n.navigation {\\n  overflow: hidden;\\n  position: fixed;\\n  z-index: 1000;\\n  top: 0;\\n  left: 0;\\n  right: 0;\\n  bottom: 0;\\n  padding-top: 3.75em;\\n  background: hsla(225, 57%, 10%, 0.9);\\n  color: #fff;\\n  transition: all 0.4s cubic-bezier(0.66, -0.01, 0.3, 0.99);\\n  -webkit-transform: translateX(105vw);\\n  transform: translateX(105vw);\\n  -webkit-backdrop-filter: blur(2px);\\n  backdrop-filter: blur(2px);\\n}\\n\\n.navigation.is-active {\\n  -webkit-transform: translateX(0);\\n  transform: translateX(0);\\n}\\n\\n.navigation li {\\n  border-bottom: 1px solid hsla(225, 57%, 30%, 0.5);\\n}\\n\\n.navigation a {\\n  display: block;\\n  padding: 1em;\\n  transition: all 0.4s ease;\\n}\\n\\n.navigation a:hover,\\n.navigation a:focus {\\n  background: #2e437c;\\n}\\n\\n/* 내비게이션 닫기 버튼 디자인 */\\n\\n.navigation .button-close-menu {\\n  position: absolute;\\n  z-index: 10;\\n  top: 10px;\\n  right: 10px;\\n  padding: 0.5em; /* 20px/40px */\\n  background: transparent;\\n  color: #fff;\\n  font-weight: 100;\\n  font-size: 2.5rem; /* 40px/16px */\\n  line-height: 0.5;\\n  transition: all 0.4s ease;\\n}\\n\\n.navigation .button-close-menu:hover,\\n.navigation .button-close-menu:focus  {\\n  -webkit-transform: scale(1.2);\\n  transform: scale(1.2);\\n}\\n\\n/* --------------------------------------------\\n  * 메인 디자인 */\\n\\n.main {\\n  margin-top: 5.625em; /* 90px */\\n  margin-left: 1.25em; /* 90px */\\n  margin-right: 1.25em; /* 90px */\\n  box-sizing: border-box;\\n  margin-bottom: 2.5em; /* 40px */\\n}\\n\\n@media screen and (min-width: 52.5em) {\\n  .main {\\n    margin-left: auto;\\n    margin-right: auto;\\n  }\\n}\\n\\n/* 메뉴 디자인 */\\n\\n.ediya-menu {\\n  display: flex;\\n  justify-content: center;\\n  align-items: center;\\n  flex-flow: row wrap;\\n}\\n\\n.ediya-menu__item {\\n  position: relative;\\n  flex: 1 1 40%;\\n  margin: 0.625em; /* 10px */\\n}\\n\\n.ediya-menu__item a {\\n  display: block;\\n  background: #f5f5f5;\\n  text-decoration: none;\\n  color: #464646;\\n}\\n\\n.ediya-menu__item figure {\\n  margin: 0;\\n  display: flex;\\n  flex-direction: column;\\n  text-align: center;\\n}\\n\\n.ediya-menu__item img {\\n  -webkit-user-select: none;\\n  -moz-user-select: none;\\n  -ms-user-select: none;\\n  user-select: none;\\n  margin-left: auto;\\n  margin-right: auto;\\n  -webkit-transform: scale(0.85);\\n  transform: scale(0.85);\\n  transition: all 0.4s ease;\\n}\\n\\n.ediya-menu__item a:hover img {\\n  -webkit-transform: scale(0.95);\\n  transform: scale(0.95);\\n}\\n\\n.ediya-menu__item figcaption {\\n  margin-top: -0.3125em; /* -5px */\\n  margin-bottom: 1.5625em; /* 25px */\\n}\\n\\n.ediya-menu__item--detail {\\n  opacity: 0;\\n  position: absolute;\\n  z-index: 500;\\n  top: 0;\\n  left: 0;\\n  right: 0;\\n  bottom: 0;\\n  border: 1px solid #e0e0e0;\\n  padding: 1.875rem 1.25em; /* 30px 20px */\\n  background: rgba(255, 255, 255, 0.6);\\n  transition: all 0.6s ease;\\n}\\n\\n.ediya-menu__item--detail.is-active {\\n  opacity: 1;\\n}\\n\\n.ediya-menu__item--name {\\n  display: block;\\n  border-bottom: solid 2px #202023;\\n  padding-bottom: 1em; /* 18px */\\n  font-weight: 400;\\n  font-size: 1.125rem; /* 18px */\\n  color: #202022;\\n}\\n\\n.ediya-menu__item--name span {\\n  display: block;\\n  font-size: 0.875rem; /* 14px */\\n  color: #737373;\\n}\\n\\n.ediya-menu__item--detail dl {\\n  line-height: 1.6;\\n  font-size: 0.8125rem; /* 13px */\\n}\\n\\n.ediya-menu__item--detail dt {\\n  float: left;\\n  width: 40%;\\n  margin-left: 10%;\\n}\\n\\n.ediya-menu__item--detail dd {\\n  float: right;\\n  width: 40%;\\n  margin-left: 0;\\n}\\n\\n.ediya-menu__item--multi-column {\\n  position: absolute;\\n  left: 0;\\n  right: 0;\\n  bottom: 0;\\n  -webkit-column-gap: 1.25em; /* 20px */\\n  column-gap: 1.25em;\\n  -webkit-column-fill: auto;\\n  column-fill: auto;\\n  -webkit-column-rule: 1px solid #999;\\n  column-rule: 1px solid #999;\\n  padding: 1em 1.5em; /* 16px 24px */\\n  background: #f8f8f8;\\n}\\n\\n.ediya-menu__item--multi-column.is-2 {\\n  -webkit-column-count: 2;\\n  column-count: 2;\\n}\\n\\n.ediya-menu__item--multi-column dl {\\n  margin: 0;\\n}\\n\\n.ediya-menu__item--multi-column span {\\n  display: block;\\n}\\n\\n.ediya-menu__item--detail .button-close-panel {\\n  position: absolute;\\n  top: 0;\\n  right: 0;\\n  padding: 0.375em 0.625em; /* 9px 15px */\\n  font-size: 1.5rem;\\n  background: transparent;\\n  transition: all 0.3s ease;\\n}\\n\\n.ediya-menu__item--detail .button-close-panel:hover {\\n  background: #f3f3f3;\\n}\\n\\n/* --------------------------------------------\\n/* 디바이스 별 미디어 쿼리 */\\n@media screen and (min-width: 1200px){\\n  .ediya-menu__item {\\n    flex-basis: 20%;\\n  }\\n}\\n\\n /* 고해상도 디스플레이를 위한 미디어 쿼리 */\\n\\n@media\\nscreen and (min-device-pixel-ratio: 2),\\nscreen and (min-resolution: 192dpi),\\nscreen and (min-resolution: 2dppx) { \\n  .header .button-navigation .ir {\\n    background-image: url(\" + ___CSS_LOADER_URL_REPLACEMENT_1___ + \");\\n  }\\n}\", \"\"]);\n// Exports\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);\n\n\n//# sourceURL=webpack://RWD/./source/style.css?./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js");

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./source/animation.css":
/*!********************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./source/animation.css ***!
  \********************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ \"./node_modules/css-loader/dist/runtime/api.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);\n// Imports\n\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \".app-header {\\n\\t/* 0% */\\n\\topacity: 0;\\n\\ttransform: translateY(-4rem);\\n\\t/* 100% */\\n\\tanimation: transform-none 0.35s 0.4s ease-out forwards;\\n}\\n\\n.brand {\\n\\topacity: 0;\\n\\ttransform: translateX(-4rem);\\n\\tanimation: transform-none 0.3s 0.7s cubic-bezier(0, 0, 0.23, 1.43) forwards;\\n}\\n\\nbutton[title=\\\"메뉴 열기\\\"] {\\n\\topacity: 0;\\n\\ttransform: translateX(4rem);\\n\\tanimation: transform-none 0.45s 0.65s cubic-bezier(0, 0, 0, 1) forwards;\\n}\\n\\n.ediya-menu__item {\\n\\topacity: 0;\\n\\ttransform: translateY(4rem);\\n\\tanimation: transform-none 0.3s 0.85s cubic-bezier(0.6, 0.01, 0.16, 1) forwards;\\n}\\n\\n.ediya-menu__item:nth-child(1) {\\n\\tanimation-duration: 0.8s;\\n}\\n.ediya-menu__item:nth-child(2) {\\n\\tanimation-duration: 1.2s;\\n}\\n.ediya-menu__item:nth-child(3) {\\n\\tanimation-duration: 1.6s;\\n}\\n.ediya-menu__item:nth-child(4) {\\n\\tanimation-duration: 2.0s;\\n}\\n\\n@keyframes transform-none {\\n\\tto {\\n\\t\\ttransform: none;\\n\\t\\topacity: 1;\\n\\t}\\n}\\n\", \"\"]);\n// Exports\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);\n\n\n//# sourceURL=webpack://RWD/./source/animation.css?./node_modules/css-loader/dist/cjs.js");

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {

eval("\n\n/*\n  MIT License http://www.opensource.org/licenses/mit-license.php\n  Author Tobias Koppers @sokra\n*/\n// css base code, injected by the css-loader\n// eslint-disable-next-line func-names\nmodule.exports = function (cssWithMappingToString) {\n  var list = []; // return the list of modules as css string\n\n  list.toString = function toString() {\n    return this.map(function (item) {\n      var content = cssWithMappingToString(item);\n\n      if (item[2]) {\n        return \"@media \".concat(item[2], \" {\").concat(content, \"}\");\n      }\n\n      return content;\n    }).join(\"\");\n  }; // import a list of modules into the list\n  // eslint-disable-next-line func-names\n\n\n  list.i = function (modules, mediaQuery, dedupe) {\n    if (typeof modules === \"string\") {\n      // eslint-disable-next-line no-param-reassign\n      modules = [[null, modules, \"\"]];\n    }\n\n    var alreadyImportedModules = {};\n\n    if (dedupe) {\n      for (var i = 0; i < this.length; i++) {\n        // eslint-disable-next-line prefer-destructuring\n        var id = this[i][0];\n\n        if (id != null) {\n          alreadyImportedModules[id] = true;\n        }\n      }\n    }\n\n    for (var _i = 0; _i < modules.length; _i++) {\n      var item = [].concat(modules[_i]);\n\n      if (dedupe && alreadyImportedModules[item[0]]) {\n        // eslint-disable-next-line no-continue\n        continue;\n      }\n\n      if (mediaQuery) {\n        if (!item[2]) {\n          item[2] = mediaQuery;\n        } else {\n          item[2] = \"\".concat(mediaQuery, \" and \").concat(item[2]);\n        }\n      }\n\n      list.push(item);\n    }\n  };\n\n  return list;\n};\n\n//# sourceURL=webpack://RWD/./node_modules/css-loader/dist/runtime/api.js?");

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/getUrl.js":
/*!********************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/getUrl.js ***!
  \********************************************************/
/***/ ((module) => {

eval("\n\nmodule.exports = function (url, options) {\n  if (!options) {\n    // eslint-disable-next-line no-param-reassign\n    options = {};\n  }\n\n  if (!url) {\n    return url;\n  } // eslint-disable-next-line no-underscore-dangle, no-param-reassign\n\n\n  url = String(url.__esModule ? url.default : url); // If url is already wrapped in quotes, remove them\n\n  if (/^['\"].*['\"]$/.test(url)) {\n    // eslint-disable-next-line no-param-reassign\n    url = url.slice(1, -1);\n  }\n\n  if (options.hash) {\n    // eslint-disable-next-line no-param-reassign\n    url += options.hash;\n  } // Should url be wrapped?\n  // See https://drafts.csswg.org/css-values-3/#urls\n\n\n  if (/[\"'() \\t\\n]|(%20)/.test(url) || options.needQuotes) {\n    return \"\\\"\".concat(url.replace(/\"/g, '\\\\\"').replace(/\\n/g, \"\\\\n\"), \"\\\"\");\n  }\n\n  return url;\n};\n\n//# sourceURL=webpack://RWD/./node_modules/css-loader/dist/runtime/getUrl.js?");

/***/ }),

/***/ "./source/animation.css":
/*!******************************!*\
  !*** ./source/animation.css ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ \"./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ \"./node_modules/style-loader/dist/runtime/styleDomAPI.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ \"./node_modules/style-loader/dist/runtime/insertBySelector.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ \"./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ \"./node_modules/style-loader/dist/runtime/insertStyleElement.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ \"./node_modules/style-loader/dist/runtime/styleTagTransform.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!../node_modules/postcss-loader/dist/cjs.js!./animation.css */ \"./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js!./source/animation.css\");\n\n      \n      \n      \n      \n      \n      \n      \n      \n      \n\nvar options = {};\n\noptions.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());\noptions.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());\n\n      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, \"head\");\n    \noptions.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());\noptions.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());\n\nvar update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_6__.default, options);\n\n\n\n\n       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_6__.default && _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_6__.default.locals ? _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_animation_css__WEBPACK_IMPORTED_MODULE_6__.default.locals : undefined);\n\n\n//# sourceURL=webpack://RWD/./source/animation.css?");

/***/ }),

/***/ "./source/style.css":
/*!**************************!*\
  !*** ./source/style.css ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ \"./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ \"./node_modules/style-loader/dist/runtime/styleDomAPI.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ \"./node_modules/style-loader/dist/runtime/insertBySelector.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ \"./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ \"./node_modules/style-loader/dist/runtime/insertStyleElement.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ \"./node_modules/style-loader/dist/runtime/styleTagTransform.js\");\n/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!../node_modules/postcss-loader/dist/cjs.js!./style.css */ \"./node_modules/css-loader/dist/cjs.js!./node_modules/postcss-loader/dist/cjs.js!./source/style.css\");\n\n      \n      \n      \n      \n      \n      \n      \n      \n      \n\nvar options = {};\n\noptions.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());\noptions.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());\n\n      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, \"head\");\n    \noptions.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());\noptions.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());\n\nvar update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__.default, options);\n\n\n\n\n       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__.default && _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__.default.locals ? _node_modules_css_loader_dist_cjs_js_node_modules_postcss_loader_dist_cjs_js_style_css__WEBPACK_IMPORTED_MODULE_6__.default.locals : undefined);\n\n\n//# sourceURL=webpack://RWD/./source/style.css?");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/***/ ((module) => {

eval("\n\nvar stylesInDom = [];\n\nfunction getIndexByIdentifier(identifier) {\n  var result = -1;\n\n  for (var i = 0; i < stylesInDom.length; i++) {\n    if (stylesInDom[i].identifier === identifier) {\n      result = i;\n      break;\n    }\n  }\n\n  return result;\n}\n\nfunction modulesToDom(list, options) {\n  var idCountMap = {};\n  var identifiers = [];\n\n  for (var i = 0; i < list.length; i++) {\n    var item = list[i];\n    var id = options.base ? item[0] + options.base : item[0];\n    var count = idCountMap[id] || 0;\n    var identifier = \"\".concat(id, \" \").concat(count);\n    idCountMap[id] = count + 1;\n    var index = getIndexByIdentifier(identifier);\n    var obj = {\n      css: item[1],\n      media: item[2],\n      sourceMap: item[3]\n    };\n\n    if (index !== -1) {\n      stylesInDom[index].references++;\n      stylesInDom[index].updater(obj);\n    } else {\n      stylesInDom.push({\n        identifier: identifier,\n        updater: addStyle(obj, options),\n        references: 1\n      });\n    }\n\n    identifiers.push(identifier);\n  }\n\n  return identifiers;\n}\n\nfunction addStyle(obj, options) {\n  var api = options.domAPI(options);\n  api.update(obj);\n  return function updateStyle(newObj) {\n    if (newObj) {\n      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {\n        return;\n      }\n\n      api.update(obj = newObj);\n    } else {\n      api.remove();\n    }\n  };\n}\n\nmodule.exports = function (list, options) {\n  options = options || {};\n  list = list || [];\n  var lastIdentifiers = modulesToDom(list, options);\n  return function update(newList) {\n    newList = newList || [];\n\n    for (var i = 0; i < lastIdentifiers.length; i++) {\n      var identifier = lastIdentifiers[i];\n      var index = getIndexByIdentifier(identifier);\n      stylesInDom[index].references--;\n    }\n\n    var newLastIdentifiers = modulesToDom(newList, options);\n\n    for (var _i = 0; _i < lastIdentifiers.length; _i++) {\n      var _identifier = lastIdentifiers[_i];\n\n      var _index = getIndexByIdentifier(_identifier);\n\n      if (stylesInDom[_index].references === 0) {\n        stylesInDom[_index].updater();\n\n        stylesInDom.splice(_index, 1);\n      }\n    }\n\n    lastIdentifiers = newLastIdentifiers;\n  };\n};\n\n//# sourceURL=webpack://RWD/./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js?");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js":
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
/***/ ((module) => {

eval("\n\nvar memo = {};\n/* istanbul ignore next  */\n\nfunction getTarget(target) {\n  if (typeof memo[target] === \"undefined\") {\n    var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself\n\n    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {\n      try {\n        // This will throw an exception if access to iframe is blocked\n        // due to cross-origin restrictions\n        styleTarget = styleTarget.contentDocument.head;\n      } catch (e) {\n        // istanbul ignore next\n        styleTarget = null;\n      }\n    }\n\n    memo[target] = styleTarget;\n  }\n\n  return memo[target];\n}\n/* istanbul ignore next  */\n\n\nfunction insertBySelector(insert, style) {\n  var target = getTarget(insert);\n\n  if (!target) {\n    throw new Error(\"Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.\");\n  }\n\n  target.appendChild(style);\n}\n\nmodule.exports = insertBySelector;\n\n//# sourceURL=webpack://RWD/./node_modules/style-loader/dist/runtime/insertBySelector.js?");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
/***/ ((module) => {

eval("\n\n/* istanbul ignore next  */\nfunction insertStyleElement(options) {\n  var style = document.createElement(\"style\");\n  options.setAttributes(style, options.attributes);\n  options.insert(style);\n  return style;\n}\n\nmodule.exports = insertStyleElement;\n\n//# sourceURL=webpack://RWD/./node_modules/style-loader/dist/runtime/insertStyleElement.js?");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\n\n/* istanbul ignore next  */\nfunction setAttributesWithoutAttributes(style) {\n  var nonce =  true ? __webpack_require__.nc : 0;\n\n  if (nonce) {\n    style.setAttribute(\"nonce\", nonce);\n  }\n}\n\nmodule.exports = setAttributesWithoutAttributes;\n\n//# sourceURL=webpack://RWD/./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js?");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js":
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
/***/ ((module) => {

eval("\n\n/* istanbul ignore next  */\nfunction apply(style, options, obj) {\n  var css = obj.css;\n  var media = obj.media;\n  var sourceMap = obj.sourceMap;\n\n  if (media) {\n    style.setAttribute(\"media\", media);\n  } else {\n    style.removeAttribute(\"media\");\n  }\n\n  if (sourceMap && typeof btoa !== \"undefined\") {\n    css += \"\\n/*# sourceMappingURL=data:application/json;base64,\".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), \" */\");\n  } // For old IE\n\n  /* istanbul ignore if  */\n\n\n  options.styleTagTransform(css, style);\n}\n\nfunction removeStyleElement(style) {\n  // istanbul ignore if\n  if (style.parentNode === null) {\n    return false;\n  }\n\n  style.parentNode.removeChild(style);\n}\n/* istanbul ignore next  */\n\n\nfunction domAPI(options) {\n  var style = options.insertStyleElement(options);\n  return {\n    update: function update(obj) {\n      apply(style, options, obj);\n    },\n    remove: function remove() {\n      removeStyleElement(style);\n    }\n  };\n}\n\nmodule.exports = domAPI;\n\n//# sourceURL=webpack://RWD/./node_modules/style-loader/dist/runtime/styleDomAPI.js?");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js":
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
/***/ ((module) => {

eval("\n\n/* istanbul ignore next  */\nfunction styleTagTransform(css, style) {\n  if (style.styleSheet) {\n    style.styleSheet.cssText = css;\n  } else {\n    while (style.firstChild) {\n      style.removeChild(style.firstChild);\n    }\n\n    style.appendChild(document.createTextNode(css));\n  }\n}\n\nmodule.exports = styleTagTransform;\n\n//# sourceURL=webpack://RWD/./node_modules/style-loader/dist/runtime/styleTagTransform.js?");

/***/ }),

/***/ "./source/helper.js":
/*!**************************!*\
  !*** ./source/helper.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"els\": () => (/* binding */ els),\n/* harmony export */   \"el\": () => (/* binding */ el)\n/* harmony export */ });\n/* -----------------------------------------------------\n * DOM 선택 헬퍼 함수 */\n\nfunction els(selector, context) {\n  if (typeof selector !== 'string' || selector.trim().length === 0) { return null; }\n  context = !context ? document : context.nodeType === 1 ? context : el(String(context));\n  return context.querySelectorAll(selector);\n}\n\nfunction el(selector, context) {\n  if (typeof selector !== 'string' || selector.trim().length === 0) { return null; }\n  context = !context ? document : context.nodeType === 1 ? context : el(String(context));\n  return context.querySelector(selector);\n}\n\n//# sourceURL=webpack://RWD/./source/helper.js?");

/***/ }),

/***/ "./source/index.js":
/*!*************************!*\
  !*** ./source/index.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _style_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./style.css */ \"./source/style.css\");\n/* harmony import */ var _animation_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./animation.css */ \"./source/animation.css\");\n/* harmony import */ var _helper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./helper.js */ \"./source/helper.js\");\n// -----------------------------------------------------------------------------------------\n// 인터랙션 UI 디자인 - OffCanvas 메뉴 / Toggle 패널\n// - DOM API, 변수, 함수, 조건문, 반복문, 연산자 등을 활용하는 총체적 예제.\n//\n// [1.1] EDIYA COFFEE 로고 오른쪽 옆에 위치한 토글 버튼(.button-open-menu)을 누르면,\n//       오프캔버스 메뉴(.navigation)을 화면에 표시한다.\n//       - hidden 속성 값 false 설정.\n//       - is-active 클래스 추가.\n//\n// [1.2] 오프캔버스 닫기 버튼(.button-close-menu)을 누르면,\n//       오프캔버스 메뉴(.navigation)을 화면에서 감춘다.\n//       - hidden 속성 값 true 설정.\n//       - is-active 클래스 제거.\n//\n// [2.1] 이디야 메뉴 아이템(.ediya-menu__item)을 문서에서 모두 수집한 후,\n//       메뉴 아이템 내부에서 a 요소를 찾아 클릭 이벤트를 연결한다.\n//       이벤트에 연결된 함수(핸들러)는 음료 상세 설명 패널을 화면에 표시한다.\n//       - 상세 설명 패널(.ediya-menu__item--detail) hidden 속성 값 false 설정.\n//       - 상세 설명 패널에 is-active 클래스 추가.\n//\n// [2.2] 상세 설명 패널 내부에 위치한 패널 닫기 버튼(.button-close-panel)을 클릭하면,\n//       패널을 닫는 이벤트 핸들러를 연결하여 패널을 닫도록 설정한다.\n//       - 상세 설명 패널(.ediya-menu__item--detail) hidden 속성 값 true 설정.\n//       - 상세 설명 패널에 is-active 클래스 제거.\n//\n//\n// 예제 참고 URL: ediya.com/contents/drink.html\n// ------------------------------------------------------------------------------------------\n\n\n\n\n\n\nvar app_header     = null;\nvar menu_open_btn  = null;\nvar app_navigation = null;\nvar menu_close_btn = null;\nvar app_main       = null;\nvar ediya_menu     = null;\nvar menu_items     = null;\n\n// 초기화\nfunction init() {\n  // 문서 객체 접근 참조\n  accessingDOMElements();\n  // 오프캔버스 메뉴 접근성\n  a11yOffCanvasMenu(app_navigation);\n  // 이벤트 바인딩\n  bindEvents();\n}\n\nfunction accessingDOMElements() {\n  app_header     = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.header');\n  menu_open_btn  = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.button-open-menu', app_header);\n  app_navigation = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.navigation', app_header);\n  menu_close_btn = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.button-close-menu', app_navigation);\n  app_main       = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.main');\n  ediya_menu     = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.ediya-menu');\n  menu_items     = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.els)('.ediya-menu__item', ediya_menu);\n}\n\nfunction bindEvents() {\n  \n  for ( var i=0, l=menu_items.length; i<l; ++i ) {\n    var menu_item = menu_items[i];\n    var link = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('a', menu_item);\n    var close_panel_btn = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.button-close-panel', menu_item);\n    link.addEventListener('click', openDetailPanel.bind(link, i));\n    close_panel_btn.addEventListener('click', closeDetailPanel);\n  }\n\n  menu_open_btn.addEventListener('click', openNavMenu);\n  menu_close_btn.addEventListener('click', closeNavMenu);\n  \n}\n\nfunction openNavMenu() {\n  app_navigation.hidden = false;\n  window.setTimeout(function(){\n    app_navigation.classList.add('is-active');\n  }, 10);\n}\n\nfunction closeNavMenu() {\n  app_navigation.classList.remove('is-active');\n  window.setTimeout(function(){\n    app_navigation.hidden = true;\n  }, 600);\n}\n\nfunction openDetailPanel(index, e) {\n  e.preventDefault();\n  var detail = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.el)('.ediya-menu__item--detail', menu_items[index]);\n  detail.hidden = false;\n  window.setTimeout(function(){\n    detail.classList.add('is-active');\n  }, 10);\n}\n\nfunction closeDetailPanel() {\n  var parent = this.parentNode;\n  parent.classList.remove('is-active');\n  window.setTimeout(function(){\n    parent.hidden = true;\n  }, 600);\n}\n\ninit();\n\n\n// -----------------------------------------------------------------\n// 오프캔버스 메뉴 접근성\n// -----------------------------------------------------------------\nfunction a11yOffCanvasMenu(app_navigation) {\n  \n  var nav_focusables      = (0,_helper_js__WEBPACK_IMPORTED_MODULE_2__.els)('a, button', app_navigation);\n  var nav_focusable_first = nav_focusables[0];\n  var nav_focusable_last  = nav_focusables[nav_focusables.length - 1];\n\n  window.addEventListener('keyup', escCloseMenu);\n  nav_focusable_first.addEventListener('keydown', navLastFocus);\n  nav_focusable_last.addEventListener('keydown', navFirstFocus);\n\n  function escCloseMenu(e){\n    if (e.keyCode === 27) { closeNavMenu(); }\n  }\n\n  function navFirstFocus(e) {\n    if (!e.shiftKey && e.keyCode === 9) {\n      window.setTimeout(function(){\n        nav_focusable_first.focus();\n      }, 10);\n    }\n  }\n\n  function navLastFocus(e) {\n    if (document.activeElement === e.target && e.shiftKey && e.keyCode === 9) {\n      nav_focusable_last.removeEventListener('keydown', navFirstFocus);\n      window.setTimeout(function(){\n        nav_focusable_last.focus();\n        nav_focusable_last.addEventListener('keydown', navFirstFocus);\n      }, 10);\n    }\n  }\n  \n}\n\nconsole.log('css', _style_css__WEBPACK_IMPORTED_MODULE_0__.default);\nconsole.log('animation', _animation_css__WEBPACK_IMPORTED_MODULE_1__.default);\n\n//# sourceURL=webpack://RWD/./source/index.js?");

/***/ }),

/***/ "./images/button-navigation.png":
/*!**************************************!*\
  !*** ./images/button-navigation.png ***!
  \**************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("module.exports = __webpack_require__.p + \"626f38b2ca19f9754fbf.png\";\n\n//# sourceURL=webpack://RWD/./images/button-navigation.png?");

/***/ }),

/***/ "./images/button-navigation@2x.png":
/*!*****************************************!*\
  !*** ./images/button-navigation@2x.png ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("module.exports = __webpack_require__.p + \"9a71309cf5694a2dbc84.png\";\n\n//# sourceURL=webpack://RWD/./images/button-navigation@2x.png?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) scriptUrl = scripts[scripts.length - 1].src
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		__webpack_require__.b = document.baseURI || self.location.href;
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"index": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// no jsonp function
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./source/index.js");
/******/ 	
/******/ })()
;